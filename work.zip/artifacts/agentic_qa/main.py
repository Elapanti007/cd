#!/usr/bin/env python3
"""
Agentic QA CLI — Backend & API Gateway focused.
Easy onboarding via agentic-qa.yaml + support for signed URLs and complex chaining.
"""
import asyncio
import argparse
import json
import yaml
from pathlib import Path
from rich.console import Console
from rich.panel import Panel

from discovery import load_spec, extract_endpoints, get_auth_summary, discover_gateway_and_common
from agent import AgenticQAAgent
from testers.api_tester import APITester
from testers.load_tester import LoadTester
from results.store import save_run, compare_regression, get_latest_run
from results.view import write_reports

console = Console()

def load_config(path: str = "agentic-qa.yaml") -> dict:
    p = Path(path)
    if p.exists():
        with open(p) as f:
            return yaml.safe_load(f) or {}
    return {}

async def main():
    parser = argparse.ArgumentParser(description="Agentic QA for backends & gateways")
    parser.add_argument("command", choices=["test", "show", "onboard"])
    parser.add_argument("--config", default="agentic-qa.yaml")
    parser.add_argument("--base-url")
    parser.add_argument("--openapi")
    parser.add_argument("--types")
    parser.add_argument("--goal")
    parser.add_argument("--model", default="gpt-4o")
    parser.add_argument("--vus", type=int, default=15)
    parser.add_argument("--duration", type=int, default=20)
    parser.add_argument("--auth-type", choices=["none", "bearer", "api_key", "basic"])
    parser.add_argument("--token")
    parser.add_argument("--header-name", default="X-API-Key")
    parser.add_argument("--username")
    parser.add_argument("--password")
    parser.add_argument("--env", help="Named environment from agentic-qa.yaml (dev, qa, staging). The URL must already be deployed.")
    parser.add_argument("--ci", action="store_true")
    parser.add_argument("--repo", default=".", help="Repo whose existing PR workflow should call the tests")
    parser.add_argument("--report", default="report.json")
    args = parser.parse_args()

    if args.command == "onboard":
        from onboard import onboard
        changed = onboard(Path(args.repo), env=args.env or "staging")
        if changed:
            for path in changed:
                console.print(f"[green]PR workflow will trigger Agentic QA:[/] {path}")
        else:
            console.print("[yellow]PR workflow already triggers Agentic QA. Nothing changed.[/]")
        return

    cfg = load_config(args.config)
    env_name = args.env
    env_cfg = {}
    if env_name:
        env_cfg = (cfg.get("environments") or {}).get(env_name) or {}
        if not env_cfg and not args.base_url:
            console.print(f"[red]Unknown environment '{env_name}'. Set it under environments: in {args.config}[/]")
            raise SystemExit(2)
        if not env_cfg:
            console.print(f"[yellow]Environment '{env_name}' is not in the config. Using the URL passed on the command line.[/]")
        else:
            console.print(f"[green]Environment:[/] {env_name}")

    base_url = args.base_url or env_cfg.get("base_url") or cfg.get("base_url")
    openapi = args.openapi or env_cfg.get("openapi") or cfg.get("openapi")
    types_str = args.types or env_cfg.get("types") or cfg.get("types", "api,flow,security,load,gateway")
    goal = args.goal or env_cfg.get("goal") or cfg.get("goal", "Full coverage including signed URL flows, stateful chains, and gateway behavior")

    auth_cfg = (env_cfg.get("auth") or cfg.get("auth") or {}).copy()
    if args.auth_type:
        auth_cfg["type"] = args.auth_type
    if args.token:
        auth_cfg["token"] = args.token
    if args.username:
        auth_cfg["username"] = args.username
    if args.password:
        auth_cfg["password"] = args.password
    if not auth_cfg.get("type"):
        auth_cfg["type"] = "none"

    if args.command == "show":
        run = get_latest_run()
        if run:
            console.print(Panel(json.dumps(run, indent=2)[:5000], title="Latest Run"))
        else:
            console.print("[yellow]No previous runs.[/]")
        return

    if not base_url and not openapi:
        console.print("[red]Provide base_url or openapi in config or via CLI[/]")
        return

    console.print(Panel.fit("[bold cyan]Agentic QA[/] — Backend & Gateway", title="QA"))
    if Path(args.config).exists():
        console.print(f"[green]Config loaded:[/] {args.config}")

    # Discovery
    endpoints = []
    auth_summary = {}
    if openapi:
        console.print(f"[green]Loading OpenAPI:[/] {openapi}")
        spec = load_spec(openapi)
        endpoints = extract_endpoints(spec)
        auth_summary = get_auth_summary(spec)
        console.print(f"  Endpoints: {len(endpoints)} | Auth schemes: {list(auth_summary.keys()) or 'none'}")
        if not base_url and endpoints and endpoints[0].get("servers"):
            base_url = endpoints[0]["servers"][0]
            console.print(f"  Using server from spec: {base_url}")
    else:
        console.print("[yellow]No OpenAPI — gateway/backend discovery[/]")
        endpoints = discover_gateway_and_common(base_url or "")

    if not base_url:
        base_url = "http://localhost"

    # Planning
    agent = AgenticQAAgent(model=args.model)
    console.print("[cyan]Agent planning tests (including signed URL & complex flows)...[/]")
    plan = agent.plan_backend_tests(endpoints, auth_summary, goal, auth_cfg)
    notes = plan.get("priority_notes", "")
    if notes:
        console.print(f"[dim]Priority:[/] {notes[:300]}")

    types = [t.strip() for t in types_str.split(",")]
    all_results = []
    api = APITester(base_url, auth_cfg)

    # Inject custom flows from config
    if cfg.get("custom_flows"):
        plan.setdefault("flows", []).extend(cfg["custom_flows"])

    # Single tests
    single_tests = []
    if "api" in types:
        single_tests.extend(plan.get("api_tests", []))
    if "security" in types:
        single_tests.extend(plan.get("security_tests", []))
    if "gateway" in types:
        single_tests.extend(plan.get("gateway_tests", []))
    if single_tests:
        console.print(f"\n[bold]Running {len(single_tests)} single-request tests[/]")
        all_results.extend(api.run_suite(single_tests[:50]))

    # Flows (including signed URL ones)
    if "flow" in types and plan.get("flows"):
        console.print(f"\n[bold]Running {len(plan['flows'])} stateful / signed-URL flows[/]")
        for flow in plan["flows"][:10]:
            console.print(f"  [magenta]{flow.get('name', 'flow')}[/]")
            steps = flow.get("steps", [])
            for step in steps:
                if step.get("rate_limit_burst"):
                    all_results.extend(api.run_rate_limit_burst(step, step.get("concurrency", 30)))
                else:
                    all_results.extend(api.run_flow([step]))


    # Load
    if "load" in types:
        console.print("\n[bold]Running Load tests[/]")
        load = LoadTester(base_url)
        targets = plan.get("load_tests") or [{"endpoint": "/health", "method": "GET"}]
        for lt in targets[:3]:
            res = await load.run(
                lt.get("endpoint", "/"),
                lt.get("method", "GET"),
                lt.get("vus", args.vus),
                lt.get("duration_seconds", args.duration)
            )
            all_results.append(res)

    # Analysis
    console.print("\n[cyan]Agent analyzing results...[/]")
    analysis = agent.analyze_results({"results": all_results}, goal)
    console.print(Panel(json.dumps(analysis, indent=2)[:3000], title="Analysis"))

    run_id = save_run(base_url, goal, all_results, analysis)
    console.print(f"[green]Saved run #{run_id}[/]")

    reg = compare_regression(all_results)
    if reg.get("regression_detected"):
        console.print(f"[bold red]REGRESSION DETECTED:[/] {reg['new_failures']}")
    else:
        console.print("[green]No new regressions vs baseline.[/]")

    failed = [r for r in all_results if not r.get("passed")]
    summary = {
        "run_id": run_id,
        "base_url": base_url,
        "goal": goal,
        "total": len(all_results),
        "failed": len(failed),
        "passed": len(all_results) - len(failed),
        "regression_detected": reg.get("regression_detected", False),
        "new_failures": reg.get("new_failures", []),
        "analysis": analysis,
        "results": all_results
    }

    if args.ci or args.report:
        with open(args.report, "w") as f:
            json.dump(summary, f, indent=2)
        paths = write_reports(summary, args.report)
        console.print(f"[green]Report written to {args.report}[/]")
        console.print(f"[green]Readable report:[/] {paths['html']}")

    console.print("[bold green]Campaign complete.[/]")

    if args.ci:
        if failed or reg.get("regression_detected"):
            console.print("[bold red]CI FAIL[/]")
            raise SystemExit(1)
        else:
            console.print("[bold green]CI PASS[/]")
            raise SystemExit(0)

if __name__ == "__main__":
    asyncio.run(main())
