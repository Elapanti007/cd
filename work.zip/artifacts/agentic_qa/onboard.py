"""Hook an existing pull-request workflow so it triggers Agentic QA."""
from pathlib import Path
import yaml

JOB = """  agentic-qa:
    uses: ./.github/workflows/agentic-qa.yml
    secrets: inherit
    with:
      environment: {env}
"""

CALLER = """name: Pull Request

on:
  pull_request:
    types: [opened, synchronize, reopened]

jobs:
  agentic-qa:
    uses: ./.github/workflows/agentic-qa.yml
    secrets: inherit
    with:
      environment: {env}
"""


def _on_block(doc):
    if not isinstance(doc, dict):
        return None
    # PyYAML reads the key "on" as boolean True.
    if "on" in doc:
        return doc["on"]
    if True in doc:
        return doc[True]
    return None


def triggers_pull_request(doc) -> bool:
    block = _on_block(doc)
    if block is None:
        return False
    if block == "pull_request":
        return True
    if isinstance(block, list):
        return "pull_request" in block
    if isinstance(block, dict):
        return "pull_request" in block
    return False


def _already_calls_qa(text: str) -> bool:
    return "agentic-qa.yml" in text or "\n  agentic-qa:" in text or text.startswith("  agentic-qa:")


def _insert_job(text: str, env: str) -> str:
    lines = text.splitlines(keepends=True)
    block = JOB.format(env=env)
    if not block.endswith("\n"):
        block += "\n"
    for i, line in enumerate(lines):
        if line.strip() == "jobs:" and (len(line) - len(line.lstrip())) == 0:
            lines.insert(i + 1, block)
            return "".join(lines)
    raise ValueError("workflow has no top-level jobs:")


def onboard(repo: Path, env: str = "staging") -> list:
    """Add the agentic-qa job to the repo's PR workflow. Returns files changed."""
    repo = repo.resolve()
    wf_dir = repo / ".github" / "workflows"
    wf_dir.mkdir(parents=True, exist_ok=True)
    changed = []
    candidates = []
    for path in sorted(wf_dir.glob("*.y*ml")):
        if path.name == "agentic-qa.yml":
            continue
        text = path.read_text(encoding="utf-8")
        try:
            doc = yaml.safe_load(text) or {}
        except Exception:
            continue
        if triggers_pull_request(doc):
            candidates.append(path)

    if not candidates:
        dest = wf_dir / "pull-request.yml"
        if not dest.exists():
            dest.write_text(CALLER.format(env=env), encoding="utf-8")
            changed.append(str(dest))
        return changed

    # One PR workflow is enough. Prefer a file that looks like the main CI.
    def rank(path: Path) -> tuple:
        name = path.name.lower()
        score = 0
        if "pull" in name or name.startswith("pr"):
            score -= 2
        if "ci" in name or "test" in name:
            score -= 1
        return (score, name)

    target = sorted(candidates, key=rank)[0]
    text = target.read_text(encoding="utf-8")
    if _already_calls_qa(text):
        return changed
    target.write_text(_insert_job(text, env), encoding="utf-8")
    changed.append(str(target))
    return changed
