# Agentic QA — Backend & API Gateway Edition

Complete AI agent for testing **microservices, API gateways, and pure backends**.

No UI. Focused on:
- All endpoints + parameters + schemas
- Auth variants (none / valid / invalid / expired) + custom headers
- Stateful multi-step flows with extraction & chaining (`{{extracted.id}}`)
- Schema-aware payload generation (valid, invalid, boundary, injection, oversized)
- Gateway-specific probes (routing, health, header propagation, rate limits)
- Security tests
- Load testing with latency percentiles
- SQLite results + automatic regression

## Easy Onboarding (1–2 hours)

1. Copy the example config:
   ```bash
   cp agentic-qa.yaml.example agentic-qa.yaml
   ```

2. Edit `agentic-qa.yaml`:
   - Set `base_url` and `openapi`
   - Set `auth` (bearer / api_key / basic)
   - Optionally list `focus_paths`
   - Add any special `custom_flows` (especially signed URL ones)

3. Run:
   ```bash
   python main.py test
   ```

That’s it. The agent will:
- Discover all endpoints from OpenAPI (or probe common paths)
- Plan auth variants, headers, payloads, and stateful flows
- Automatically handle **signed URLs**: extract the URL from a response, then call that full URL (with optional transforms)

### How endpoints are chosen
- If you give an OpenAPI → agent sees every endpoint + schema + auth requirement
- You can limit with `focus_paths` in the config
- Without OpenAPI → it probes health, swagger, graphql, /api, /v1, etc.

### Auth & Headers
- Set once in `agentic-qa.yaml` under `auth` and `default_headers`
- Agent still generates negative variants (none / invalid / expired) unless you disable them

## Optional: Deeper property-based testing

For maximum edge-case coverage, you can run Schemathesis in parallel (it generates thousands of inputs from the OpenAPI schema):

```bash
pip install schemathesis
schemathesis run https://api.example.com/openapi.json \
  --base-url https://api.example.com \
  --checks all \
  --stateful=links
```

Combine its findings with the agentic runs for both intelligent chaining and brute-force boundary coverage. 
 
 

### CI / PR
Same as before — just point the workflow at your `agentic-qa.yaml` (or pass secrets as overrides). 


### Auth flags
```bash
--auth-type none|bearer|api_key|basic
--token <value>
--header-name X-API-Key
--username / --password
```

## What the agent plans & runs

| Category | Examples |
|----------|----------|
| **api_tests** | Single calls with auth/header/payload variations |
| **flows** | Create → extract ID → GET/PUT/DELETE with `{{extracted.item_id}}` |
| **security_tests** | Invalid tokens, missing auth, injection payloads, oversized bodies |
| **gateway_tests** | Health, routing paths, header passthrough, version checks |
| **load_tests** | Concurrent VUs + p95 latency + success rate |
| **graphql_tests** | Basic query/mutation if GraphQL detected |

## Chaining example (agent-generated)

```json
{
  "name": "create-item-flow",
  "steps": [
    {
      "endpoint": "/items",
      "method": "POST",
      "payload_type": "valid",
      "extract": {"item_id": "id"},
      "expected_status": 201
    },
    {
      "endpoint": "/items/{{extracted.item_id}}",
      "method": "GET",
      "expected_status": 200
    }
  ]
}
```

## PR / CI Workflow

The agent is designed to run on every pull request.

### 1. Copy the workflow
The ready-to-use workflow is at:

```
.github/workflows/agentic-qa.yml
```

### 2. Required secrets (in GitHub repo settings)
| Secret | Purpose |
|--------|---------|
| `OPENAI_API_KEY` | LLM for planning & analysis |
| `TARGET_BASE_URL` | Staging / preview environment URL |
| `OPENAPI_URL` | URL or path to OpenAPI (can be a file in the repo) |
| `AUTH_TOKEN` | Optional Bearer token for the target |

### 3. What happens on each PR
- Checkout + install deps
- Runs full backend/gateway campaign (`--ci`)
- Writes `report.json`
- Uploads the report as an artifact
- Comments a short summary on the PR
- **Fails the check** if any tests fail or a regression is detected

## Newly added features

| Feature | How to use | What it does |
|---------|------------|--------------|
| **Concurrent rate-limit burst** | `rate_limit_burst: true` + `concurrency: 40` | Fires real parallel requests and checks for 429 + Retry-After |
| **Idempotency-Key replay** | `generate_idempotency_key: true` then reuse `{{extracted.last_idempotency_key}}` | Auto-generates UUID, tracks first response, fails if replay differs |
| **Response schema validation** | `validate_response_schema: true` | Lightweight check that response matches expected type/required fields |

Example:

```yaml
custom_flows:
  - name: "rate-limit-burst"
    steps:
      - endpoint: "/v1/users"
        method: GET
        rate_limit_burst: true
        concurrency: 40
        expected_status: [200, 429]
```
 
 
