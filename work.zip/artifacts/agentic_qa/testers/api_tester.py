"""
API tester with stateful chaining, schema-aware payloads, gateway support,
auth variants, and security probes. Backend / gateway focused.
"""
import httpx
import json
import re
import random
import string
import uuid
import asyncio
from typing import List, Dict, Any, Optional
from rich.console import Console
from concurrent.futures import ThreadPoolExecutor, as_completed

console = Console()

class APITester:
    def __init__(self, default_base_url: str, auth_config: Optional[Dict] = None, timeout: float = 20.0):
        self.default_base_url = default_base_url.rstrip("/")
        self.auth_config = auth_config or {}
        self.client = httpx.Client(timeout=timeout, follow_redirects=True)
        self.extracted: Dict[str, Any] = {}  # for chaining: key → value
        self.idempotency_store: Dict[str, Dict] = {}  # key → first response for replay checks


    def _build_headers(self, test: Dict) -> Dict[str, str]:
        headers = {
            "User-Agent": "AgenticQA-Backend/1.0",
            "Accept": "application/json",
            "X-Request-ID": f"qa-{''.join(random.choices(string.ascii_lowercase + string.digits, k=8))}"
        }
        # Default auth
        if self.auth_config.get("type") == "bearer" and self.auth_config.get("token"):
            headers["Authorization"] = f"Bearer {self.auth_config['token']}"
        elif self.auth_config.get("type") == "api_key":
            name = self.auth_config.get("header_name", "X-API-Key")
            headers[name] = self.auth_config.get("key", "")
        # Test-level overrides
        if test.get("headers"):
            headers.update(test["headers"])
        # Auth variant
        variant = test.get("auth_variant", "valid")
        if variant == "none":
            headers.pop("Authorization", None)
            headers.pop("X-API-Key", None)
            headers.pop("X-Api-Key", None)
        elif variant == "invalid":
            headers["Authorization"] = "Bearer invalid.token.xyz"
        elif variant == "expired":
            headers["Authorization"] = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.expired"
        # Auto-generate Idempotency-Key if requested
        if test.get("generate_idempotency_key"):
            key = str(uuid.uuid4())
            headers["Idempotency-Key"] = key
            self.extracted["last_idempotency_key"] = key

        return headers

    def _generate_payload(self, schema: Dict, payload_type: str = "valid") -> Any:
        """Simple schema-aware payload generator (property-based lite)."""
        if not schema or not isinstance(schema, dict):
            return {"generated": True}
        t = schema.get("type", "object")
        if payload_type == "empty":
            return {}
        if payload_type == "invalid_type":
            return "not-an-object" if t == "object" else 99999
        if t == "object":
            props = schema.get("properties", {})
            required = set(schema.get("required", []))
            obj = {}
            for k, v in props.items():
                if payload_type == "missing_required" and k in required:
                    continue
                obj[k] = self._generate_payload(v, payload_type)
            if payload_type == "boundary" and props:
                # inject extreme value
                first = next(iter(props))
                obj[first] = "A" * 10000
            return obj
        if t == "string":
            fmt = schema.get("format")
            if fmt == "email":
                return "test@agentic-qa.local"
            if fmt == "date-time":
                return "2026-01-01T00:00:00Z"
            if payload_type == "boundary":
                return "A" * 5000
            if payload_type == "unicode":
                return "测试 🚀 ñ é ü 田中太郎"
            if payload_type == "null":
                return None
            if payload_type == "injection":
                return "'; DROP TABLE users; --"
            return "agentic-qa-" + "".join(random.choices(string.ascii_lowercase, k=6))
        if t == "integer":
            return 0 if payload_type == "boundary" else random.randint(1, 1000)
        if t == "number":
            return 0.0 if payload_type == "boundary" else round(random.uniform(1, 100), 2)
        if t == "boolean":
            return True
        if t == "array":
            item = schema.get("items", {})
            if payload_type == "empty":
                return []
            if payload_type == "boundary":
                return [self._generate_payload(item, "valid")] * 100
            return [self._generate_payload(item, payload_type)]
        return None

    def _substitute_extracted(self, value: Any) -> Any:
        """Replace {{extracted.key}} placeholders with previously extracted values."""
        if isinstance(value, str):
            def repl(m):
                key = m.group(1)
                return str(self.extracted.get(key, m.group(0)))
            return re.sub(r"\{\{extracted\.(\w+)\}\}", repl, value)
        if isinstance(value, dict):
            return {k: self._substitute_extracted(v) for k, v in value.items()}
        if isinstance(value, list):
            return [self._substitute_extracted(v) for v in value]
        return value

    def _extract_value(self, body: Any, path: str) -> Any:
        """Simple JSON path extractor: 'data.upload_url' or 'id'."""
        val = body
        for part in path.split("."):
            if isinstance(val, dict):
                val = val.get(part)
            elif isinstance(val, list) and part.isdigit():
                val = val[int(part)]
            else:
                return None
        return val

    def _apply_url_transform(self, url: str, test: Dict) -> str:
        """Optional transform for signed URLs (e.g. add/replace query params)."""
        if not test.get("transform_url"):
            return url
        # Example: force a query param or strip signature for negative test
        if "negative" in test.get("description", "").lower():
            # strip signature for failure case
            from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
            parsed = urlparse(url)
            qs = parse_qs(parsed.query)
            qs.pop("signature", None)
            qs.pop("sig", None)
            new_query = urlencode(qs, doseq=True)
            return urlunparse(parsed._replace(query=new_query))
        return url

    def run_test(self, test: Dict) -> Dict:
        method = test.get("method", "GET").upper()
        path = test.get("endpoint") or test.get("path", "/")
        base = test.get("base_url") or self.default_base_url

        # Substitute extracted values
        path = self._substitute_extracted(path)

        # Support full signed URL as the endpoint
        if path.startswith("http://") or path.startswith("https://"):
            url = path
        else:
            url = f"{base}{path}" if path.startswith("/") else f"{base}/{path}"

        url = self._apply_url_transform(url, test)

        headers = self._build_headers(test)
        payload = test.get("payload")
        if payload is None and method in ("POST", "PUT", "PATCH"):
            schema = test.get("schema") or {}
            payload = self._generate_payload(schema, test.get("payload_type", "valid"))
        payload = self._substitute_extracted(payload)

        try:
            # Handle raw body for file-like uploads
            kwargs = {"headers": headers}
            if isinstance(payload, str) and test.get("raw_body"):
                kwargs["content"] = payload.encode()
            else:
                kwargs["json"] = payload if payload is not None else None

            resp = self.client.request(method, url, **kwargs)

            expected = test.get("expected_status", 200)
            passed = (resp.status_code in expected) if isinstance(expected, list) else (resp.status_code == expected)

            # Advanced extraction
            extracted_now = {}
            if test.get("extract"):
                try:
                    body = resp.json() if "application/json" in resp.headers.get("content-type", "") else {}
                    for key, jpath in test["extract"].items():
                        val = self._extract_value(body, jpath)
                        if val is not None:
                            self.extracted[key] = val
                            extracted_now[key] = val
                except Exception:
                    pass

            # Response schema validation (lite)
            schema_ok = True
            schema_error = None
            if test.get("validate_response_schema") and resp.status_code < 500:
                try:
                    body = resp.json() if "application/json" in resp.headers.get("content-type", "") else None
                    if body is not None and test.get("response_schema"):
                        schema_ok = self._validate_against_schema(body, test["response_schema"])
                        if not schema_ok:
                            schema_error = "Response does not match expected schema"
                except Exception as e:
                    schema_ok = False
                    schema_error = str(e)

            passed = passed and schema_ok

            # Idempotency tracking
            if "Idempotency-Key" in headers:
                idemp_key = headers["Idempotency-Key"]
                if idemp_key not in self.idempotency_store:
                    self.idempotency_store[idemp_key] = {
                        "status": resp.status_code,
                        "body": resp.text[:1000]
                    }
                else:
                    # Replay check
                    prev = self.idempotency_store[idemp_key]
                    if prev["status"] != resp.status_code or prev["body"] != resp.text[:1000]:
                        passed = False
                        schema_error = (schema_error or "") + " | Idempotency mismatch on replay"

            return {
                "type": "api",
                "endpoint": path,
                "method": method,
                "base_url": base,
                "final_url": url,
                "auth_variant": test.get("auth_variant"),
                "payload_type": test.get("payload_type"),
                "status_code": resp.status_code,
                "expected": expected,
                "passed": passed,
                "response_time_ms": round(resp.elapsed.total_seconds() * 1000, 1),
                "body_snippet": resp.text[:500],
                "extracted": extracted_now,
                "schema_ok": schema_ok,
                "schema_error": schema_error,
                "description": test.get("description", "")
            }
        except Exception as e:
            return {
                "type": "api",
                "endpoint": path,
                "method": method,
                "passed": False,
                "error": str(e),
                "description": test.get("description", "")
            }

    def _validate_against_schema(self, data: Any, schema: Dict) -> bool:
        """Very lightweight schema check (type + required fields)."""
        if not schema:
            return True
        expected_type = schema.get("type")
        if expected_type == "object" and not isinstance(data, dict):
            return False
        if expected_type == "array" and not isinstance(data, list):
            return False
        if expected_type == "string" and not isinstance(data, str):
            return False
        if expected_type == "integer" and not isinstance(data, int):
            return False
        if expected_type == "number" and not isinstance(data, (int, float)):
            return False
        if expected_type == "boolean" and not isinstance(data, bool):
            return False
        if expected_type == "object" and isinstance(data, dict):
            for req in schema.get("required", []):
                if req not in data:
                    return False
            # recurse on properties if present
            props = schema.get("properties", {})
            for k, subschema in props.items():
                if k in data and not self._validate_against_schema(data[k], subschema):
                    return False
        return True

    def run_rate_limit_burst(self, test: Dict, concurrency: int = 30) -> List[Dict]:
        """Fire concurrent requests to trigger rate limiting."""
        console.print(f"  [yellow]Rate-limit burst:[/] {concurrency} concurrent requests")
        results = []

        def single():
            return self.run_test(test)

        with ThreadPoolExecutor(max_workers=concurrency) as pool:
            futures = [pool.submit(single) for _ in range(concurrency)]
            for fut in as_completed(futures):
                try:
                    results.append(fut.result())
                except Exception as e:
                    results.append({"passed": False, "error": str(e), "description": "burst error"})

        # Analyze
        statuses = [r.get("status_code") for r in results if r.get("status_code")]
        has_429 = 429 in statuses
        has_retry_after = any(
            "retry-after" in str(r.get("body_snippet", "")).lower() or
            "retry-after" in str(r.get("headers", {})).lower()
            for r in results
        )
        summary = {
            "type": "rate_limit_burst",
            "concurrency": concurrency,
            "total": len(results),
            "status_codes": dict((s, statuses.count(s)) for s in set(statuses)),
            "saw_429": has_429,
            "saw_retry_after": has_retry_after,
            "passed": has_429,  # success if we triggered limiting
            "description": test.get("description", "rate limit burst")
        }
        results.append(summary)
        return results

    def run_flow(self, steps: List[Dict]) -> List[Dict]:
        """Run a multi-step stateful flow (chaining via extract)."""
        results = []
        console.print(f"  [cyan]Flow:[/] {len(steps)} steps")
        for i, step in enumerate(steps):
            r = self.run_test(step)
            mark = "[green]PASS[/]" if r.get("passed") else "[red]FAIL[/]"
            console.print(f"    {i+1}. {mark} {r['method']} {r['endpoint'][:40]} → {r.get('status_code', 'ERR')}")
            results.append(r)
            if not r.get("passed") and step.get("stop_on_fail", True):
                break
        return results

    def run_suite(self, tests: List[Dict]) -> List[Dict]:
        results = []
        for t in tests:
            if t.get("type") == "flow" or "steps" in t:
                results.extend(self.run_flow(t.get("steps", [])))
            else:
                r = self.run_test(t)
                mark = "[green]PASS[/]" if r.get("passed") else "[red]FAIL[/]"
                auth = r.get("auth_variant") or "-"
                console.print(f"  {mark} {r['method']:6} {r['endpoint'][:45]:45} [{auth}] → {r.get('status_code', 'ERR')}")
                results.append(r)
        return results
