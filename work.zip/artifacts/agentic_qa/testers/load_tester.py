"""
Simple concurrent load tester.
"""
import asyncio
import httpx
import time
from typing import Dict, List
from statistics import mean, quantiles
from rich.console import Console

console = Console()

class LoadTester:
    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")

    async def _hit(self, client: httpx.AsyncClient, method: str, path: str, payload=None) -> Dict:
        url = f"{self.base_url}{path}" if path.startswith("/") else f"{self.base_url}/{path}"
        start = time.perf_counter()
        try:
            resp = await client.request(method, url, json=payload)
            elapsed = (time.perf_counter() - start) * 1000
            return {"ok": resp.status_code < 500, "status": resp.status_code, "latency_ms": elapsed}
        except Exception as e:
            elapsed = (time.perf_counter() - start) * 1000
            return {"ok": False, "error": str(e), "latency_ms": elapsed}

    async def run(self, endpoint: str, method: str = "GET", vus: int = 10, duration: int = 30) -> Dict:
        console.print(f"[cyan]Load test:[/] {method} {endpoint} | {vus} VUs for {duration}s")
        results = []
        start = time.perf_counter()
        
        async with httpx.AsyncClient(timeout=10.0) as client:
            while time.perf_counter() - start < duration:
                tasks = [self._hit(client, method, endpoint) for _ in range(vus)]
                batch = await asyncio.gather(*tasks)
                results.extend(batch)
                await asyncio.sleep(0.1)  # small think time

        latencies = [r["latency_ms"] for r in results if "latency_ms" in r]
        ok_count = sum(1 for r in results if r.get("ok"))
        total = len(results)
        error_rate = 1 - (ok_count / total) if total else 1

        p95 = round(quantiles(latencies, n=20)[-1], 2) if len(latencies) > 10 else None
        p99 = round(quantiles(latencies, n=100)[-1], 2) if len(latencies) > 20 else None

        summary = {
            "type": "load",
            "endpoint": endpoint,
            "method": method,
            "vus": vus,
            "duration_s": duration,
            "total_requests": total,
            "success_rate": round(ok_count / total, 3) if total else 0,
            "error_rate": round(error_rate, 3),
            "avg_latency_ms": round(mean(latencies), 2) if latencies else None,
            "p95_latency_ms": p95,
            "p99_latency_ms": p99,
            "passed": (error_rate < 0.05) if total else False
        }
        console.print(f"  → {total} reqs | success {summary['success_rate']:.1%} | avg {summary['avg_latency_ms']}ms | p95 {p95}ms | p99 {p99}ms")
        return summary
