"""
SQLite results store + regression comparison.
"""
import sqlite3
import json
from datetime import datetime
from typing import Dict, List, Optional
from pathlib import Path

DB_PATH = Path("qa_results.db")

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            base_url TEXT,
            goal TEXT,
            summary TEXT
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id INTEGER,
            type TEXT,
            name TEXT,
            passed INTEGER,
            details TEXT,
            FOREIGN KEY(run_id) REFERENCES runs(id)
        )
    """)
    conn.commit()
    conn.close()

def save_run(base_url: str, goal: str, all_results: List[Dict], analysis: Dict) -> int:
    init_db()
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute(
        "INSERT INTO runs (timestamp, base_url, goal, summary) VALUES (?, ?, ?, ?)",
        (datetime.utcnow().isoformat(), base_url, goal, json.dumps(analysis))
    )
    run_id = c.lastrowid
    for r in all_results:
        c.execute(
            "INSERT INTO results (run_id, type, name, passed, details) VALUES (?, ?, ?, ?, ?)",
            (run_id, r.get("type"), r.get("endpoint") or r.get("goal") or "unknown", 
             1 if r.get("passed") else 0, json.dumps(r))
        )
    conn.commit()
    conn.close()
    return run_id

def get_latest_run() -> Optional[Dict]:
    if not DB_PATH.exists():
        return None
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT id, timestamp, base_url, goal, summary FROM runs ORDER BY id DESC LIMIT 1")
    row = c.fetchone()
    if not row:
        conn.close()
        return None
    run = {"id": row[0], "timestamp": row[1], "base_url": row[2], "goal": row[3], "summary": json.loads(row[4] or "{}")}
    c.execute("SELECT type, name, passed, details FROM results WHERE run_id = ?", (row[0],))
    run["results"] = [{"type": r[0], "name": r[1], "passed": bool(r[2]), "details": json.loads(r[3])} for r in c.fetchall()]
    conn.close()
    return run

def compare_regression(current_results: List[Dict], baseline: Optional[Dict] = None) -> Dict:
    if not baseline:
        baseline = get_latest_run()
    if not baseline:
        return {"status": "no_baseline", "message": "First run - no regression to compare"}
    
    baseline_map = {f"{r['type']}:{r['name']}": r["passed"] for r in baseline.get("results", [])}
    new_failures = []
    for r in current_results:
        key = f"{r.get('type')}:{r.get('endpoint') or r.get('goal') or 'unknown'}"
        if key in baseline_map and baseline_map[key] and not r.get("passed"):
            new_failures.append(key)
    
    return {
        "status": "compared",
        "baseline_run_id": baseline.get("id"),
        "new_failures": new_failures,
        "regression_detected": len(new_failures) > 0
    }
