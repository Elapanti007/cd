"""Human-readable reports so a person can see what ran and what failed."""
import html
import json
from pathlib import Path
from typing import Dict, List


def _row(r: Dict) -> Dict:
    return {
        "type": r.get("type") or "",
        "method": r.get("method") or "",
        "name": r.get("endpoint") or r.get("goal") or r.get("description") or "",
        "expected": r.get("expected", ""),
        "status": r.get("status_code", r.get("error", "")),
        "ms": r.get("response_time_ms", r.get("avg_latency_ms", "")),
        "passed": bool(r.get("passed")),
        "detail": (r.get("schema_error") or r.get("error") or r.get("description") or "")[:300],
        "body": (r.get("body_snippet") or "")[:400],
    }


def write_reports(summary: Dict, json_path: str) -> Dict[str, str]:
    base = Path(json_path)
    base.parent.mkdir(parents=True, exist_ok=True)
    rows = [_row(r) for r in summary.get("results") or []]
    rows.sort(key=lambda r: r["passed"])

    md_path = base.with_suffix(".md")
    html_path = base.with_name(base.stem + ".html")
    comment_path = base.with_name("pr-comment.md")

    md_path.write_text(_markdown(summary, rows), encoding="utf-8")
    html_path.write_text(_html(summary, rows), encoding="utf-8")
    comment_path.write_text(_markdown(summary, rows, limit=40)[:60000], encoding="utf-8")
    return {"markdown": str(md_path), "html": str(html_path), "comment": str(comment_path)}


def _markdown(summary: Dict, rows: List[Dict], limit: int = 0) -> str:
    shown = rows if not limit else rows[:limit]
    lines = [
        "# Agentic QA",
        "",
        f"- Base URL: `{summary.get('base_url')}`",
        f"- Passed: **{summary.get('passed', 0)}** / {summary.get('total', 0)}",
        f"- Failed: **{summary.get('failed', 0)}**",
        f"- Regression: {'YES' if summary.get('regression_detected') else 'no'}",
        "",
        "| Result | Method | Target | Expected | Got | ms | Why |",
        "|---|---|---|---|---|---|---|",
    ]
    for r in shown:
        mark = "PASS" if r["passed"] else "FAIL"
        lines.append(
            "| {mark} | {method} | `{name}` | {expected} | {status} | {ms} | {detail} |".format(
                mark=mark,
                method=r["method"],
                name=str(r["name"]).replace("|", "/")[:80],
                expected=r["expected"],
                status=r["status"],
                ms=r["ms"],
                detail=str(r["detail"]).replace("|", "/").replace("\n", " ")[:120],
            )
        )
    if limit and len(rows) > limit:
        lines.append("")
        lines.append(f"_Showing {limit} of {len(rows)}. Open the HTML artifact for the full list._")
    analysis = (summary.get("analysis") or {}).get("summary")
    if analysis:
        lines.extend(["", "## Analysis", "", str(analysis)])
    return "\n".join(lines) + "\n"


def _html(summary: Dict, rows: List[Dict]) -> str:
    body_rows = []
    for r in rows:
        cls = "pass" if r["passed"] else "fail"
        body_rows.append(
            "<tr class='{cls}'><td>{mark}</td><td>{method}</td><td><code>{name}</code></td>"
            "<td>{expected}</td><td>{status}</td><td>{ms}</td><td>{detail}</td><td><pre>{body}</pre></td></tr>".format(
                cls=cls,
                mark="PASS" if r["passed"] else "FAIL",
                method=html.escape(str(r["method"])),
                name=html.escape(str(r["name"])[:120]),
                expected=html.escape(str(r["expected"])),
                status=html.escape(str(r["status"])),
                ms=html.escape(str(r["ms"])),
                detail=html.escape(str(r["detail"])),
                body=html.escape(str(r["body"])),
            )
        )
    return """<!doctype html>
<html><head><meta charset="utf-8"><title>Agentic QA</title>
<style>
body {{ font: 14px/1.4 ui-sans-serif, system-ui, sans-serif; margin: 24px; background: #111; color: #eee; }}
table {{ border-collapse: collapse; width: 100%; }}
td, th {{ border: 1px solid #333; padding: 6px 8px; vertical-align: top; text-align: left; }}
tr.fail {{ background: #3a1515; }}
tr.pass {{ background: #122416; }}
pre {{ white-space: pre-wrap; margin: 0; max-width: 360px; }}
code {{ word-break: break-all; }}
</style></head><body>
<h1>Agentic QA</h1>
<p>Base: {base}<br>Passed {passed} / {total}. Failed {failed}. Regression: {reg}</p>
<table>
<thead><tr><th></th><th>Method</th><th>Target</th><th>Expected</th><th>Got</th><th>ms</th><th>Why</th><th>Body</th></tr></thead>
<tbody>
{rows}
</tbody></table>
<h2>Analysis</h2>
<pre>{analysis}</pre>
</body></html>
""".format(
        base=html.escape(str(summary.get("base_url") or "")),
        passed=summary.get("passed", 0),
        total=summary.get("total", 0),
        failed=summary.get("failed", 0),
        reg="YES" if summary.get("regression_detected") else "no",
        rows="\n".join(body_rows),
        analysis=html.escape(json.dumps(summary.get("analysis") or {}, indent=2)[:8000]),
    )
