"""
Backend / Gateway focused agent.
Plans tests for microservices, API gateways, auth, routing, rate limits, stateful flows.
"""
import os
import json
from typing import List, Dict, Any, Optional
from openai import OpenAI

class AgenticQAAgent:
    def __init__(self, model: str = "gpt-4o", base_url: Optional[str] = None, api_key: Optional[str] = None):
        self.client = OpenAI(
            api_key=api_key or os.getenv("OPENAI_API_KEY"),
            base_url=base_url or os.getenv("OPENAI_BASE_URL")
        )
        self.model = model
        self.system_prompt = """You are a senior Backend & API Gateway QA Engineer.

Focus exclusively on:
- Microservices and API Gateways (Apigee, Kong, AWS, Envoy, Traefik, custom)
- All auth schemes and variants (including revoked, insufficient scope, JWT edge cases)
- Header propagation, correlation IDs, rate limiting, routing, path rewriting
- Stateful multi-step flows with extraction
- **Use response of one endpoint as payload / URL / header of the next** via {{extracted.key}}
- **Signed URLs / pre-signed links**
- **Idempotency**: use `generate_idempotency_key: true` then replay the same request. Runner tracks and flags mismatches.
- **Rate limiting**: use `rate_limit_burst: true` with concurrency for true parallel 429 testing.
- **Response schema validation**: set `validate_response_schema: true` + optional `response_schema`.
- **BOLA/IDOR**: create as one user, access with another.
- Payload generation covering unicode, null, empty arrays, oversized, boundary, injection
- Response schema conformance and undocumented status codes
- Pagination edge cases (empty, last page, oversized)
- Security and gateway behavior
- GraphQL if present

Always output pure structured JSON. Prefer realistic chainable flows that cover the edge cases above.
"""

    def chat(self, messages: List[Dict], temperature: float = 0.1) -> str:
        resp = self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "system", "content": self.system_prompt}] + messages,
            temperature=temperature,
        )
        return resp.choices[0].message.content

    def plan_backend_tests(
        self,
        endpoints: List[Dict],
        auth_summary: Dict,
        goal: str,
        user_auth_config: Optional[Dict] = None,
        previous_results: Optional[Dict] = None
    ) -> Dict:
        ep_sample = endpoints[:30]
        context = {
            "endpoint_count": len(endpoints),
            "sample_endpoints": ep_sample,
            "auth_schemes": auth_summary,
            "user_auth": user_auth_config or {},
            "goal": goal,
            "previous": previous_results or "none"
        }
        prompt = f"""Plan a complete backend + gateway test campaign.

DATA:
{json.dumps(context, indent=2)[:14000]}

Return JSON with these keys only:

1. api_tests: list of single-request tests:
   {{
     "endpoint": "/path",
     "method": "GET|POST|...",
     "auth_variant": "none|valid|invalid|expired",
     "headers": {{}},
     "payload": {{}} or null,
     "payload_type": "valid|invalid_type|missing_required|boundary|empty|injection",
     "schema": {{...}} (optional, for generation),
     "expected_status": 200 or [200,201],
     "description": "..."
   }}

2. flows: list of stateful multi-step flows:
   {{
     "name": "create-then-get",
     "steps": [
       {{ "endpoint": "/items", "method": "POST", "payload_type": "valid", "extract": {{"item_id": "id"}}, "expected_status": 201 }},
       {{ "endpoint": "/items/{{extracted.item_id}}", "method": "GET", "expected_status": 200 }}
     ]
   }}

3. security_tests: auth bypass, injection, oversized, rate-limit probes

4. gateway_tests: routing, header propagation, path rewrite, version checks, health of gateway

5. load_tests: {{endpoint, method, vus, duration_seconds}}

6. graphql_tests: if GraphQL endpoints detected (query/mutation strings)

7. priority_notes: string
8. entry_points: list of base URLs or paths to cover

Be aggressive on coverage of auth, headers, payloads, and chaining. Use {{extracted.key}} syntax for chaining.
"""
        raw = self.chat([{"role": "user", "content": prompt}])
        if "```json" in raw:
            raw = raw.split("```json")[1].split("```")[0]
        elif "```" in raw:
            raw = raw.split("```")[1].split("```")[0]
        try:
            return json.loads(raw)
        except Exception as e:
            return {"error": "parse_failed", "raw": raw[:2500], "exception": str(e)}

    def analyze_results(self, results: Dict, goal: str) -> Dict:
        prompt = f"""Analyze backend/gateway test results.

Results: {json.dumps(results, indent=2)[:12000]}
Goal: {goal}

Return JSON:
- summary
- critical_failures
- auth_and_gateway_issues
- chaining_or_state_issues
- payload_and_schema_issues
- performance_and_rate_limit_notes
- coverage_gaps
- recommended_next_actions
- regression_flags
"""
        raw = self.chat([{"role": "user", "content": prompt}])
        if "```json" in raw:
            raw = raw.split("```json")[1].split("```")[0]
        try:
            return json.loads(raw)
        except:
            return {"raw": raw[:2000]}
