"""
Discovery focused on backends, gateways, and microservices.
"""
import json
import yaml
import httpx
from typing import List, Dict, Any
from urllib.parse import urljoin

def load_spec(source: str) -> Dict:
    if source.startswith("http"):
        resp = httpx.get(source, timeout=30)
        resp.raise_for_status()
        content = resp.text
    else:
        with open(source) as f:
            content = f.read()
    if source.endswith((".yaml", ".yml")) or "openapi:" in content[:800] or "swagger:" in content[:800]:
        return yaml.safe_load(content)
    return json.loads(content)

def extract_security_schemes(spec: Dict) -> Dict[str, Dict]:
    components = spec.get("components", {})
    schemes = components.get("securitySchemes", {})
    if not schemes and "securityDefinitions" in spec:
        schemes = spec["securityDefinitions"]
    return schemes

def extract_servers(spec: Dict) -> List[str]:
    servers = spec.get("servers", [])
    urls = [s.get("url", "") for s in servers if s.get("url")]
    if not urls and "host" in spec:
        scheme = spec.get("schemes", ["https"])[0]
        base = spec.get("basePath", "")
        urls = [f"{scheme}://{spec['host']}{base}"]
    return urls or [""]

def extract_endpoints(spec: Dict) -> List[Dict]:
    endpoints = []
    paths = spec.get("paths", {})
    security_schemes = extract_security_schemes(spec)
    global_security = spec.get("security", [])
    servers = extract_servers(spec)

    for path, methods in paths.items():
        for method, details in methods.items():
            if method.lower() not in ("get", "post", "put", "patch", "delete", "head", "options"):
                continue
            parameters = []
            for p in details.get("parameters", []):
                parameters.append({
                    "name": p.get("name"),
                    "in": p.get("in"),
                    "required": p.get("required", False),
                    "schema": p.get("schema", {}),
                    "description": (p.get("description") or "")[:200]
                })
            request_body = details.get("requestBody", {})
            content = request_body.get("content", {})
            body_schemas = {ctype: cdef.get("schema", {}) for ctype, cdef in content.items()}
            op_security = details.get("security", global_security)
            ep = {
                "path": path,
                "method": method.upper(),
                "summary": details.get("summary", ""),
                "description": (details.get("description") or "")[:400],
                "parameters": parameters,
                "request_body_schemas": body_schemas,
                "responses": {
                    code: {"description": r.get("description", ""), "schema": r.get("content", {})}
                    for code, r in details.get("responses", {}).items()
                },
                "security": op_security,
                "tags": details.get("tags", []),
                "servers": servers,
                "available_auth_schemes": list(security_schemes.keys()),
                "is_graphql": "graphql" in path.lower()
            }
            endpoints.append(ep)
    return endpoints

def get_auth_summary(spec: Dict) -> Dict:
    schemes = extract_security_schemes(spec)
    summary = {}
    for name, scheme in schemes.items():
        summary[name] = {
            "type": scheme.get("type"),
            "scheme": scheme.get("scheme"),
            "in": scheme.get("in"),
            "name": scheme.get("name"),
            "flows": list(scheme.get("flows", {}).keys()) if scheme.get("type") == "oauth2" else None
        }
    return summary

def discover_gateway_and_common(base_url: str) -> List[Dict]:
    """Aggressive discovery for backends and gateways."""
    candidates = [
        "/health", "/ready", "/live", "/status", "/ping",
        "/api/health", "/actuator/health", "/metrics",
        "/swagger.json", "/openapi.json", "/api/swagger.json", "/v3/api-docs",
        "/docs", "/api-docs", "/redoc",
        "/v1", "/v2", "/api/v1", "/api/v2", "/gateway", "/api",
        "/graphql", "/graphiql", "/playground",
        "/admin", "/internal", "/.well-known/openid-configuration"
    ]
    found = []
    for c in candidates:
        try:
            r = httpx.get(urljoin(base_url, c), timeout=6, follow_redirects=True)
            if r.status_code < 500:
                found.append({
                    "path": c,
                    "method": "GET",
                    "status": r.status_code,
                    "summary": "Discovered (gateway/backend probe)",
                    "parameters": [],
                    "security": [],
                    "content_type": r.headers.get("content-type", "")
                })
        except Exception:
            pass
    return found
